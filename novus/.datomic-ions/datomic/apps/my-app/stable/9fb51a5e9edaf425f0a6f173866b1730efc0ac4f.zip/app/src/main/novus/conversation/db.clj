(ns novus.conversation.db)

(defn find-conversations-by-account-id
  [])

(defn transact-message
  [])

(defn transact-conversation
  [])

(defn find-messages-by-conversation-id
  [])

(defn read-messages
  [])
